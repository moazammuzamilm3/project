import React from 'react';
import Dosa from '../images/dosa.jpg';
import Chola from '../images/chhola.jpg';
import Idli from '../images/idli.jpg';
import MaslaDosa from '../images/masala.jpg';
import Paneer from '../images/paneer.jpg';
import Gujrati from '../images/gujrati.jpeg';

// export default function data() {
//   return (
//     <div>data</div>
//   )
// }

export const MenuList =[
    {
        name:'Dosa',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry !',
        image:Dosa,
        price:200
    },
    {
        name:'Chola',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry !',
        image:Chola,
        price:250
    },
    {
        name:'Idli',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry !',
        image:Idli,
        price:300
    },
    {
        name:'MaslaDosa',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry !',
        image:MaslaDosa,
        price:350
    },
    {
        name:'Paneer',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry !',
        image:Paneer,
        price:150
    },
    {
        name:'Gujrati',
        description:'Lorem Ipsum is simply dummy text of the printing and typesetting industry !',
        image:Gujrati,
        price:100
    },
]
