import React from 'react'
import Layout from '../Components/layout/Layout'

export default function Pagenofound() {
  return (
    <div>
      <Layout>
      Pagenofound
      </Layout>
      </div>
  )
}
