import React from "react";
import Layout from "../Components/layout/Layout";
import { MenuList } from "../data/data";
import { Box, Card, CardActionArea, CardContent, CardMedia, Typography } from "@mui/material";

export default function Menu() {
  return (
    <div>
      <Layout>
        <Box sx={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
          {MenuList.map((memu) => (
            <Card sx={{ maxWidth:'390px' , display:"flex" , m:2 }}>
              <CardActionArea>
                <CardMedia
                  sx={{ minHeight: "400px" }}
                  component={"img"}
                  src={memu.image}
                  alt={memu.name}
                />
                <CardContent>
                  <Typography variant="h5" gutterBottom component={'div'}>
                  {memu.name}
                  </Typography>
                  <Typography variant="body2" >
                    {memu.description}  
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          ))}
        </Box>
      </Layout>
    </div>
  );
}
